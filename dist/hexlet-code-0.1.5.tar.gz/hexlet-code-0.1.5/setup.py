# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*'], 'gendiff': ['files/*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff_script:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.5',
    'description': '',
    'long_description': None,
    'author': 'Albert Gevorkyan',
    'author_email': 'agevork@yandex.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
